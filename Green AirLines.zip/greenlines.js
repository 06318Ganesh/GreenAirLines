document.getElementById("bookingForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent the form from submitting

    // Get form data
    var formData = new FormData(this);

    // Display booking information
    alert("Booking successful!\nName: " + formData.get("name") + "\nEmail: " + formData.get("email") + "\nPhone: " + formData.get("phone"));
});